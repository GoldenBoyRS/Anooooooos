const express = require('express');
const cors = require('cors');
const path = require('path');

function createServer(manager) {
    const app = express(); 
    
    app.use(cors());
    app.use(express.json());
    app.use(express.static(path.join(__dirname, '..', 'public')));

    app.get('/api/pair', async (req, res) => {
        const number = req.query.number;
        if (!number) return res.status(400).json({ error: 'Numéro requis' });

        try {
            let session = manager.getSession(number);
            
            if (session && ['loggedOut', 'error', 'disconnected'].includes(session.status)) {
                manager.sessions.delete(number.replace(/[^0-9]/g, '')); 
                session = null; 
            }

            if (session && session.status === 'open') {
                return res.json({ status: 'already_connected' });
            }

            if (!session) {
                session = await manager.createSession(number);
            }

            let attempts = 0;
            while (!session.pairingCode && session.status !== 'open' && session.status !== 'error' && attempts < 10) {
                await new Promise(r => setTimeout(r, 1000));
                attempts++;
            }

            if (session.status === 'open') {
                return res.json({ status: 'already_connected' });
            }

            if (session.status === 'error' || !session.pairingCode) {
                return res.status(500).json({ error: 'Échec de la génération (Numéro invalide ou WhatsApp a refusé)' });
            }

            res.json({ status: 'pairing', code: session.pairingCode });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });

    app.get('/api/status', (req, res) => {
        const number = req.query.number;
        if (!number) return res.status(400).json({ error: 'Numéro requis' });
        res.json(manager.getStatus(number));
    });

    app.get('/api/sessions', (req, res) => {
        res.json({ sessions: manager.listSessions() });
    });

    return app;
}

module.exports = createServer;