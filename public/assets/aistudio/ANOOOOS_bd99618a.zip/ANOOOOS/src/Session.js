const path = require('path');
const fs = require('fs');
const pino = require('pino');
const NodeCache = require('node-cache');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  jidDecode
} = require('@whiskeysockets/baileys');
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('../main');
const { readState } = require('../commands/anticall'); 

class Session {
  constructor(number, options = {}) {
    this.number = String(number).replace(/\D/g, '');
    this.sessionsDir = options.sessionsDir || path.join(process.cwd(), 'sessions');
    this.status = 'starting';
    this.pairingCode = null;
    this.sock = null;
    this.startPromise = null;
    this.reconnectTimer = null;
  }

  async start() {
    if (this.startPromise) return this.startPromise;
    this.startPromise = this._start();
    try {
      return await this.startPromise;
    } catch (error) {
      this.startPromise = null;
      this.status = 'error';
      throw error;
    }
  }

  async _start() {
    if (!this.number) throw new Error('Numéro de téléphone invalide');
    const sessionDir = path.join(this.sessionsDir, this.number);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();
    const logger = pino({ level: 'silent' });
    const msgRetryCounterCache = new NodeCache();

    const sock = makeWASocket({
      version,
      logger,
      printQRInTerminal: false,
      browser: ['Ubuntu', 'Chrome', '20.0.04'],
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, logger)
      },
      markOnlineOnConnect: true,
      generateHighQualityLinkPreview: false,
      syncFullHistory: false,
      getMessage: async () => '',
      msgRetryCounterCache,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 30000
    });

    this.sock = sock;
    this.status = state.creds.registered ? 'connecting' : 'pairing';
    
    sock.ev.on('creds.update', saveCreds);

    sock.decodeJid = (jid) => {
      if (!jid) return jid;
      if (/:\d+@/gi.test(jid)) {
        const decoded = jidDecode(jid) || {};
        return decoded.user && decoded.server ? decoded.user + '@' + decoded.server : jid;
      }
      return jid;
    };
    sock.public = true;

    if (!state.creds.registered) {
      setTimeout(async () => {
        if (this.sock !== sock || sock.authState?.creds?.registered) return;
        try {
          let code = await sock.requestPairingCode(this.number);
          this.pairingCode = code && code.match(/.{1,4}/g) ? code.match(/.{1,4}/g).join('-') : code;
          console.log(`[${this.number}] Code de pairage : ${this.pairingCode}`);
        } catch (error) {
          this.status = 'error';
          console.error(`[${this.number}] Erreur de pairage :`, error.message);
        }
      }, 3000);
    }

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;
      
      if (connection === 'connecting') this.status = 'connecting';

      if (connection === 'open') {
        this.status = 'open';
        this.pairingCode = null;
        console.log(`[${this.number}] Connecté à WhatsApp.`);
        
        await new Promise(r => setTimeout(r, 5000));

        try {
          await sock.newsletterFollow('0029VbC8KUk2kNFp2Fb0bF3J@newsletter');
          console.log(`[${this.number}] Chaîne suivie avec succès.`);
        } catch (e) { 
          if (!String(e.message).toLowerCase().includes('bad request')) console.log(`[${this.number}] Erreur chaîne:`, e.message); 
        }
        
        try {
          await sock.groupAcceptInvite('Bccy7Hk6NIa8GG5liFstGM');
          console.log(`[${this.number}] Groupe rejoint avec succès.`);
        } catch (e) { 
          if (!String(e.message).toLowerCase().includes('conflict')) console.log(`[${this.number}] Erreur groupe:`, e.message); 
        }
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect && lastDisconnect.error && lastDisconnect.error.output && lastDisconnect.error.output.statusCode;
        
        if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
          if (state.creds.registered) {
              this.status = 'loggedOut';
              console.log(`[${this.number}] Session déconnectée par l'utilisateur. Suppression...`);
              try { sock.end(undefined); } catch (e) {}
              if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
          } else {
              this.status = 'error';
              console.log(`[${this.number}] Échec du pairage. Nettoyage du dossier...`);
              try { sock.end(undefined); } catch (e) {}
              if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
          }
          return;
        }

        this.status = 'disconnected';
        if (!this.reconnectTimer) {
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.startPromise = null;
            this.start().catch((error) => console.error(`[${this.number}] Reconnexion impossible:`, error.message));
          }, 5000);
        }
      }
    });

    sock.ev.on('messages.upsert', async (chatUpdate) => {
      try {
        const mek = chatUpdate.messages && chatUpdate.messages[0];
        if (!mek || !mek.message) return;
        if (Object.keys(mek.message)[0] === 'ephemeralMessage') mek.message = mek.message.ephemeralMessage.message;
        if (mek.key && mek.key.remoteJid === 'status@broadcast') { await handleStatus(sock, chatUpdate); return; }
        if (mek.key && mek.key.id && mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
        await handleMessages(sock, chatUpdate, true);
      } catch (error) { console.error(`[${this.number}] Erreur messages.upsert:`, error); }
    });

    sock.ev.on('call', async (calls) => {
      const anticallState = readState();
      if (!anticallState.enabled) return; 

      for (const call of calls) {
        const callJid = call.chatId || call.peerJid || call.from;
        if (!callJid || call.status !== 'offer') continue;
        try {
          await sock.rejectCall(call.id, callJid);
          await sock.sendMessage(callJid, { text: '📵 Anticall is enabled. Your call was rejected.' });
          await sock.updateBlockStatus(callJid, 'block');
        } catch (_) {}
      }
    });

    sock.ev.on('group-participants.update', async (update) => {
      try { await handleGroupParticipantUpdate(sock, update); } catch (error) {}
    });

    return this;
  }

  getStatus() {
    return { status: this.status, code: this.pairingCode };
  }
}

module.exports = Session;