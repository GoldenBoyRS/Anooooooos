const fs = require('fs');
const path = require('path');
const SessionManager = require('./src/SessionManager');
const createServer = require('./src/server');

async function start() {
  const sessionsDir = path.join(__dirname, 'sessions');
  fs.mkdirSync(sessionsDir, { recursive: true });

  const manager = new SessionManager({ sessionsDir });
  await manager.init();

  const app = createServer(manager);
  const port = Number(process.env.PORT) || 20356;
  
  app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Panel ANOS VOLDI MULTI disponible sur le port ${port}`);
  });

  setInterval(() => {
    if (typeof global.gc === 'function') global.gc();
  }, 60000);
}

start().catch((error) => {
  console.error('Erreur au démarrage :', error);
  process.exitCode = 1;
});

process.on('uncaughtException', (error) => console.error('Uncaught Exception:', error));
process.on('unhandledRejection', (error) => console.error('Unhandled Rejection:', error));